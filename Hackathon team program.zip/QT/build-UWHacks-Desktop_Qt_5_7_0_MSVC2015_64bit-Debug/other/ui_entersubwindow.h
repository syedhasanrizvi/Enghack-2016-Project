/********************************************************************************
** Form generated from reading UI file 'entersubwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ENTERSUBWINDOW_H
#define UI_ENTERSUBWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Entersubwindow
{
public:
    QLabel *label;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;

    void setupUi(QDialog *Entersubwindow)
    {
        if (Entersubwindow->objectName().isEmpty())
            Entersubwindow->setObjectName(QStringLiteral("Entersubwindow"));
        Entersubwindow->resize(585, 348);
        QIcon icon;
        icon.addFile(QStringLiteral("../../physics.png"), QSize(), QIcon::Normal, QIcon::On);
        Entersubwindow->setWindowIcon(icon);
        Entersubwindow->setWindowOpacity(1);
        Entersubwindow->setAutoFillBackground(false);
        label = new QLabel(Entersubwindow);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(0, 10, 581, 61));
        QFont font;
        font.setPointSize(20);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);
        layoutWidget = new QWidget(Entersubwindow);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(-50, 120, 671, 161));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        QFont font1;
        font1.setPointSize(15);
        pushButton->setFont(font1);

        verticalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setFont(font1);

        verticalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(layoutWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setFont(font1);

        verticalLayout->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(layoutWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        QFont font2;
        font2.setPointSize(14);
        pushButton_4->setFont(font2);

        verticalLayout->addWidget(pushButton_4);


        horizontalLayout->addLayout(verticalLayout);


        retranslateUi(Entersubwindow);

        QMetaObject::connectSlotsByName(Entersubwindow);
    } // setupUi

    void retranslateUi(QDialog *Entersubwindow)
    {
        Entersubwindow->setWindowTitle(QApplication::translate("Entersubwindow", "Start Menu", 0));
        label->setText(QApplication::translate("Entersubwindow", "Please Select An Exercise", 0));
        pushButton->setText(QApplication::translate("Entersubwindow", "What Is The Projectile's Final Velocity?", 0));
        pushButton_2->setText(QApplication::translate("Entersubwindow", "What Is The Initial Velocity Of The Projectile?", 0));
        pushButton_3->setText(QApplication::translate("Entersubwindow", "How Far Does The Projectile Go?", 0));
        pushButton_4->setText(QApplication::translate("Entersubwindow", "How Long Does It Take The Projectile To Reach A Certain Range?", 0));
    } // retranslateUi

};

namespace Ui {
    class Entersubwindow: public Ui_Entersubwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ENTERSUBWINDOW_H
