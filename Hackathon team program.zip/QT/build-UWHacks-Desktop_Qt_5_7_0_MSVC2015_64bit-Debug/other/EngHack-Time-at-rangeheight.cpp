#include<iostream>
#include<math.h>

using namespace std;

int main ()
{
	float inith; //Initial Height
	float initv; //Initial velocity
	float angle; //Initial angle
	float dx, dy; //Horizontal and vertical ranges
	float t,t1; //Times outputed
	const float tol = 0.001; //Tolerance for float variables
	
	
	//Takes in initial height
	cout << "What's the initial height? (in metres) ";
	cin >> inith;
	
	//Error check for initial height
	char next = cin.get();
	if(!cin.good()||next !='\n' || inith<0)
	{	cerr<<"Error: Objects can't have that height!!";
		return -1;
	}
	
	//Takes in velocity	
	cout << "What's the initial velocity? (in metres/second) ";
	cin >> initv;
	
	//Error check for initial velocity
	next = cin.get();
	if(!cin.good()||next !='\n'|| initv<0)
	{	cerr << "Error: Input another velocity!!";
		return -1;
	}

	//Takes in angle
	cout << "The initial angle? (must be between 0 and 90 degrees) ";
	cin >> angle;
	
	//Error check for angle
	next = cin.get();
	if(!cin.good()||next !='\n' || angle>=90 || angle<=0)
	{	cerr<<"Error: Put another angle!!";
		return -1;
	}
			
	//Converts degrees to radians
	float rad = angle*(M_PI/180);
	
	//User decision variable
	char userc;
	
	//Asks if user wants a specific vertical or horizontal displacement
	cout << "Would you like the time at a specific vertical or horizontal displacement (v/h)? ";
	cin >> userc;
	
	//After user deicision
	if (userc == 'h' || userc == 'H')
	{
		//Takes in specific horizontal displacement
		cout << "At what horizontal displacement? (positive and in metres) ";
		cin >> dx;
		
		//Error check for horizontal displacement
		next = cin.get();
		if(!cin.good()||next !='\n'||dx<0)
		{	cerr<<"Error: Horizontal displacement must be a positive number!!";
		return -1;
		}
		
		//Calculate total horizontal range
		float dxtot = ((initv*(cos(rad)))/9.81)*((initv*(sin(rad))) + sqrt(initv*initv*sin(rad)*sin(rad) + 2*9.81*inith));
		
		//Calculate time
		t = dx/(initv*(cos(rad)));
		
		//Check if dx in horizontal range
		if (dx>dxtot)
		{
			cerr << "Error: The value you entered exceeds the total range of " << dxtot << " metre(s)";
			return -1;
		}
		
		//If in range, output time
		else {
			cout << "Time at " << dx << " metre(s) is " << t << " second(s)";
		}
			
	}
	
	else if (userc == 'v' || userc == 'V')
	{
		//Takes in specific vertical displacement
		cout << "At what vertical displacement? (in metres) ";
		cin >> dy;
		
		//Error check for vertical displacement
		next = cin.get();
		if(!cin.good()||next !='\n')
		{	cerr<<"Error: Vertical displacement must be a number!!";
		return -1;
		}
				
		//Error check for vertical displacement compared to height
		if ((dy + inith) < tol)
		{
			cerr << "Error: The object is travelling through the floor!!";
			return -1;
		}
		
		//Calulate time at vertical displacement
		t = ((initv*(sin(rad)))/9.81 - sqrt((initv*(sin(rad)))*(initv*(sin(rad)))/(9.81*9.81) - 2*dy/9.81));
		
		t1 = ((initv*(sin(rad)))/9.81 + sqrt((initv*(sin(rad)))*(initv*(sin(rad)))/(9.81*9.81) - 2*dy/9.81));
				
					
		//Error check for value in square root
		if ((sqrt((initv*(sin(rad)))*(initv*(sin(rad)))/(9.81*9.81) - 2*dy/9.81))<0){
			cerr << "Error: The vertical displacement " << dy << " metre(s) isn't in the projectile's motion";
			return -1;
		}
										
		//Outputs times
		if (t>=0 && t1>=0){
			cout << "Times at " << dy << " metre(s) are " << t << " second(s) and " << t1 << " second(s)";
		}
		
		else if (t>=0 && t1<0) 
		{
			cout << "Time at " << dy << " metre(s) is " << t << " second(s)";
		}
		
		else if (t<0 && t1>=0) 
		{
			cout << "Time at " << dy << " metre(s) is " << t1 << " second(s)";		
		}
		
		else
		{
			cout << "You're going back in time!! All of the times are negative for this displacement!!";
		}
		
	}
	
	//Error check for user decision
	else {
		cerr << "Error: Invalid input!! Read the instructions properly next time!!";
		return -1;
	}
		
	return 0;
}