/********************************************************************************
** Form generated from reading UI file 'maxheightwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAXHEIGHTWINDOW_H
#define UI_MAXHEIGHTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>

QT_BEGIN_NAMESPACE

class Ui_maxheightwindow
{
public:

    void setupUi(QDialog *maxheightwindow)
    {
        if (maxheightwindow->objectName().isEmpty())
            maxheightwindow->setObjectName(QStringLiteral("maxheightwindow"));
        maxheightwindow->resize(640, 480);

        retranslateUi(maxheightwindow);

        QMetaObject::connectSlotsByName(maxheightwindow);
    } // setupUi

    void retranslateUi(QDialog *maxheightwindow)
    {
        maxheightwindow->setWindowTitle(QApplication::translate("maxheightwindow", "Dialog", 0));
    } // retranslateUi

};

namespace Ui {
    class maxheightwindow: public Ui_maxheightwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAXHEIGHTWINDOW_H
