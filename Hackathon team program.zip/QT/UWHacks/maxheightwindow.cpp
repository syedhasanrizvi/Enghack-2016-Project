#include "maxheightwindow.h"
#include "ui_maxheightwindow.h"

maxheightwindow::maxheightwindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::maxheightwindow)
{
    ui->setupUi(this);
}

maxheightwindow::~maxheightwindow()
{
    delete ui;
}
