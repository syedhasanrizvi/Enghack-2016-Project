#include "entersubwindow.h"
#include "ui_entersubwindow.h"
#include "maxheightwindow.h"
#include <qdesktopservices.h>
#include <QUrl>
#include <qfiledialog.h>
#include <qmessagebox.h>
Entersubwindow::Entersubwindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Entersubwindow)
{
    ui->setupUi(this);

}

Entersubwindow::~Entersubwindow()
{
    delete ui;
}

void Entersubwindow::on_pushButton_clicked()
{
    QString filename = QFileDialog::getOpenFileName (
               this,
                tr("Open File"),
                "Desktop/numberfour.exe",
                "All files (*.*);;Text File (*.txt);;Music file(*mp3) "

                );

    QDesktopServices::openUrl(QUrl("file:///"+filename,QUrl::TolerantMode));
    //QMessageBox::information(this, tr("file name"),filename);

}

void Entersubwindow::on_pushButton_2_clicked()
{
    QString filename = QFileDialog::getOpenFileName (
               this,
                tr("Open File"),
                "Desktop/numberfour.exe",
                "All files (*.*);;Text File (*.txt);;Music file(*mp3) "

                );

    QDesktopServices::openUrl(QUrl("file:///"+filename,QUrl::TolerantMode));
    //QMessageBox::information(this, tr("file name"),filename);
}

void Entersubwindow::on_pushButton_3_clicked()
{
    QString filename = QFileDialog::getOpenFileName (
               this,
                tr("Open File"),
                "Desktop/numberfour.exe",
                "All files (*.*);;Text File (*.txt);;Music file(*mp3) "

                );

    QDesktopServices::openUrl(QUrl("file:///"+filename,QUrl::TolerantMode));
    //QMessageBox::information(this, tr("file name"),filename);
}

void Entersubwindow::on_pushButton_6_clicked()
{
    QString filename = QFileDialog::getOpenFileName (
               this,
                tr("Open File"),
                "Desktop/numberfour.exe",
                "All files (*.*);;Text File (*.txt);;Music file(*mp3) "

                );

    QDesktopServices::openUrl(QUrl("file:///"+filename,QUrl::TolerantMode));
    //QMessageBox::information(this, tr("file name"),filename);
}

void Entersubwindow::on_pushButton_7_clicked()
{
    QString filename = QFileDialog::getOpenFileName (
               this,
                tr("Open File"),
                "Desktop/numberfour.exe",
                "All files (*.*);;Text File (*.txt);;Music file(*mp3) "

                );

    QDesktopServices::openUrl(QUrl("file:///"+filename,QUrl::TolerantMode));
    //QMessageBox::information(this, tr("file name"),filename);
}

void Entersubwindow::on_pushButton_8_clicked()
{
    QString filename = QFileDialog::getOpenFileName (
               this,
                tr("Open File"),
                "Desktop/numberfour.exe",
                "All files (*.*);;Text File (*.txt);;Music file(*mp3) "

                );

    QDesktopServices::openUrl(QUrl("file:///"+filename,QUrl::TolerantMode));
    //QMessageBox::information(this, tr("file name"),filename);
}

void Entersubwindow::on_pushButton_4_clicked()
{
    QString filename = QFileDialog::getOpenFileName (
               this,
                tr("Open File"),
                "Desktop/numberfour.exe",
                "All files (*.*);;Text File (*.txt);;Music file(*mp3) "

                );

    QDesktopServices::openUrl(QUrl("file:///"+filename,QUrl::TolerantMode));
    //QMessageBox::information(this, tr("file name"),filename);
}

void Entersubwindow::on_pushButton_5_clicked()
{
    QString filename = QFileDialog::getOpenFileName (
               this,
                tr("Open File"),
                "Desktop/numberfour.exe",
                "All files (*.*);;Text File (*.txt);;Music file(*mp3) "

                );

    QDesktopServices::openUrl(QUrl("file:///"+filename,QUrl::TolerantMode));
    //QMessageBox::information(this, tr("file name"),filename);
}
