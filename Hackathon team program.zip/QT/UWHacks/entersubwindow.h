#ifndef ENTERSUBWINDOW_H
#define ENTERSUBWINDOW_H

#include <QDialog>

namespace Ui {
class Entersubwindow;
}

class Entersubwindow : public QDialog
{
    Q_OBJECT

public:
    explicit Entersubwindow(QWidget *parent = 0);
    ~Entersubwindow();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

private:
    Ui::Entersubwindow *ui;
};

#endif // ENTERSUBWINDOW_H
