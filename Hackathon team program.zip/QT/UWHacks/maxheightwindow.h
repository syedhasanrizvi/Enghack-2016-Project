#ifndef MAXHEIGHTWINDOW_H
#define MAXHEIGHTWINDOW_H

#include <QDialog>

namespace Ui {
class maxheightwindow;
}

class maxheightwindow : public QDialog
{
    Q_OBJECT

public:
    explicit maxheightwindow(QWidget *parent = 0);
    ~maxheightwindow();

private:
    Ui::maxheightwindow *ui;
};

#endif // MAXHEIGHTWINDOW_H
